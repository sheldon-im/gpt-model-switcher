---
name: "(Advanced) Feature from add-on"
about: "Free text feature request template for those familiar with GitHub."
labels: ["enhancement", "Addon/integration"]
---

### Describe the specific functionality to be integrated

### What problem does this functionality solve?

### Why should this be in NVDA vs. remaining an add-on?

### Source Add-on Information
* **Name of the source add-on:**
* **Link to add-on repository or website:**
* **Current maintainer(s) of the add-on:**
* **Add-on license:**

### Additional context
