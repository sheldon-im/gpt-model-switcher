# Create NVDA Development Environment

## Getting the Source Code

The NVDA project uses the [git](https://www.git-scm.com/) version control system for its source code and documentation.

The NVDA repository is located at <https://github.com/nvaccess/nvda>.

If you plan on contributing to NVDA, you will need to [fork and clone](https://docs.github.com/en/get-started/quickstart/fork-a-repo) the repository.

After forking the repository into your user account (`YOUR-USERNAME`), clone with `--recursive` to fetch all required submodules.

```sh
git clone --recursive https://github.com/YOUR-USERNAME/nvda.git
```

### Keeping the fork in sync

When you fork the repository, GitHub will create a copy of the master branch.
However, this branch will not be updated when the NV Access master branch is updated.
To ensure your work is always based on the latest commit in the `nvaccess/nvda` master branch, it is recommended that your master branch be linked to the `nvaccess/nvda` master branch, rather than the master branch in your GitHub fork.
You can do this from the command line as follows:

```sh
# Add a remote for the NV Access repository.
git remote add nvaccess https://github.com/nvaccess/nvda.git
# Fetch the NV Access branches.
git fetch nvaccess
# Switch to the local master branch.
git checkout master
# Set the local master to use the NV Access master as its upstream.
git branch -u nvaccess/master
# Update the local master.
git pull
```

## Supported Operating Systems

At a minimum, running and building NVDA from source requires Windows 10 (Version 1507).
We recommend Windows 11 to work with features under active support, and if you need to use Windows 10, use Version 22H2.

## Dependencies

The NVDA source depends on several other packages to run correctly.

### Installed Dependencies

The following dependencies need to be installed on your system:

#### Python

[Python](https://www.python.org/), version 3.13.15, 64-bit.
Install the python version listed in [.python-versions](../../.python-versions)

#### uv

[uv](https://docs.astral.sh/uv/) is used as package and project manager.

#### Microsoft Visual Studio

* Microsoft Visual Studio 2022 or 2026
  * To replicate the production build environment, use the [version of Visual Studio 2022 that GitHub Actions is using](https://github.com/actions/runner-images/tree/main/images/windows).
  * If you don't use the Visual Studio IDE itself, you can download the [build tools](https://aka.ms/vs/17/release/vs_BuildTools.exe).
  * If you do intend to use the Visual Studio IDE (not required for NVDA development), you can download [the community version](https://aka.ms/vs/17/release/vs_Community.exe).
    * The Professional and Enterprise versions are also supported.
    * Preview or insiders versions are *not* supported.
* When installing Visual Studio, additional components must be included:
  * You can automatically fetch these using [NVDAs .vsconfig](../../.vsconfig) using the [import feature of the VS installer](https://learn.microsoft.com/en-us/visualstudio/install/import-export-installation-configurations?view=vs-2022#import-a-configuration).
  * In the list on the Workloads tab, in the Desktop grouping:
    * Desktop development with C++.
      * Once selected, ensure "C++ Clang tools for Windows" is included under the optional grouping.
  * On the Individual components tab, ensure the following items are selected:
    * Windows 11 SDK (10.0.26100.x)
    * MSVC v143 - VS 2022 C++ ARM64/ARM64EC build tools
    * MSVC v143 - VS 2022 C++ x64/x86 build tools
    * C++ ATL for v143 build tools (x86 & x64)
    * C++ ATL for v143 build tools (ARM64/ARM64EC)

### Git Submodules

Some of the dependencies are contained in [Git submodules](https://git-scm.com/docs/gitsubmodules).
If you didn't pass the `--recursive` option to git clone, you will need to run `git submodule update --init`.
Whenever a required submodule commit changes (e.g. after git pull), you will need to run `git submodule update`.
If you aren't sure, run `git submodule update` after every git pull, merge or checkout.

#### Run time dependencies

* [eSpeak NG](https://github.com/espeak-ng/espeak-ng), commit `f1354994057fa9b85001675732e7fed2d437292b`
* [Sonic](https://github.com/waywardgeek/sonic), commit `b93885dcb70aae50c6f76b0fe4e0868f029a077e`
* [IAccessible2](https://wiki.linuxfoundation.org/accessibility/iaccessible2/start), commit `c9ae003d9c85eb707716928de97e055f5b77189c`
* [liblouis](http://www.liblouis.io/), version 3.39.0
* [Unicode Common Locale Data Repository (CLDR)](http://cldr.unicode.org/), version 48.2
* [Adobe Acrobat accessibility interface, version XI](https://download.macromedia.com/pub/developer/acrobat/AcrobatAccess.zip)
* [Microsoft Detours](https://github.com/microsoft/Detours), commit `9764cebcb1a75940e68fa83d6730ffaf0f669401`
* brlapi Python bindings, version 0.8.7 or later, built with [GitHub Actions in the NV Access fork of the brlTTY repository](https://github.com/nvaccess/brltty/actions)
* lilli.dll, version 2.1.0.0
* [Nullsoft Install System](https://nsis.sourceforge.io), version 3.11
* [Java Access Bridge 64 bit, from Zulu Community OpenJDK build 17.0.16+8 Zulu (17.60.17)](https://github.com/nvaccess/javaAccessBridge32-bin)
* [Windows Implementation Library (WIL)](https://github.com/microsoft/wil/), commit `7cf41936c5b4ab79daf0d9437211380dc69fa958`
* [cppjieba - Chinese word segmentation](https://github.com/yanyiwu/cppjieba), commit `b3602bef7d1f67521a61788a74fb5801a0e62cd3`

#### Build time dependencies

The following build time dependencies are included in the miscDeps git submodule:

* xgettext and msgfmt from [GNU gettext](https://github.com/mlocati/gettext-iconv-windows/tags)

#### VS Code

* If you use [Visual Studio Code](https://code.visualstudio.com/) as your integrated development environment, you get the benefit of our [prepopulated workspace configuration](https://github.com/nvaccess/vscode-nvda/), which is included as a submodule.
  If you do not wish to use the pre-populated VS Code workspace configuration, you can unregister the `.vscode` submodule.

  ```sh
  git submodule deinit .vscode
  ```

  If you change your mind, you can re-enable it at any time.

  ```sh
  git submodule init .vscode
  ```

### Python dependencies

NVDA and its build system also depend on an extensive list of Python packages.
They are all listed with their specific versions in the `pyproject.toml` file in the root of this repository.
However, the build system takes care of fetching these itself when needed.
These packages will be installed into an isolated Python virtual environment within this repository, and will not affect your system-wide set of packages.

### Other dependencies

The following dependencies aren't needed by most people:

* To generate [developer documentation for nvdaHelper](./buildingDevDocumentation.md#building-nvdahelper-developer-documentation): [Doxygen Windows installer](http://www.doxygen.nl/download.html), version 1.8.15.
